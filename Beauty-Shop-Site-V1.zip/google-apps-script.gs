/*
BEAUTY SHOP — GOOGLE APPS SCRIPT
Cole este código em script.google.com e conecte a uma planilha.

ABAS:
1) Produtos
2) Leads

Produtos: id | name | platform | category | oldPrice | price | discount | image | description | note | affiliateUrl | whatsapp | active
Leads: data | nome | email | origem

Depois de publicar como Web App, use a URL no site.
*/
const SHEET_ID = "COLE_AQUI_O_ID_DA_SUA_PLANILHA";

function doGet(e) {
  const action = e && e.parameter ? e.parameter.action : "";
  if (action === "products") {
    const ss = SpreadsheetApp.openById(SHEET_ID);
    const sh = ss.getSheetByName("Produtos");
    const values = sh.getDataRange().getValues();
    const headers = values.shift();
    const products = values
      .filter(r => String(r[headers.indexOf("active")]).toLowerCase() !== "false")
      .map(r => {
        const o = {};
        headers.forEach((h,i)=>o[h]=r[i]);
        return o;
      });
    return ContentService.createTextOutput(JSON.stringify(products))
      .setMimeType(ContentService.MimeType.JSON);
  }
  return ContentService.createTextOutput(JSON.stringify({ok:true,service:"Beauty Shop"}))
    .setMimeType(ContentService.MimeType.JSON);
}

function doPost(e) {
  const p = e.parameter || {};
  const ss = SpreadsheetApp.openById(SHEET_ID);
  const sh = ss.getSheetByName("Leads");
  sh.appendRow([new Date(), p.nome || "", p.email || "", p.origem || "site"]);

  if (p.email) {
    GmailApp.sendEmail(
      p.email,
      "Bem-vinda à Beauty Shop",
      `Olá, ${p.nome || ""}!\n\nSeu cadastro no Beauty VIP foi recebido. Você passará a receber seleções e novidades da Beauty Shop.\n\nBeauty Shop`
    );
  }
  return ContentService.createTextOutput(JSON.stringify({ok:true}))
    .setMimeType(ContentService.MimeType.JSON);
}
