# BEAUTY SHOP — SITE V1

Esta é a primeira versão funcional da vitrine digital da Beauty Shop.

## O que já existe
- Site responsivo.
- Visual editorial/minimalista.
- Busca por produto.
- Filtro por plataforma.
- Categorias.
- Cards de produtos.
- Página/modal individual do produto.
- Preço anterior, atual e desconto.
- Botão "Ver oferta" para seu link de afiliada.
- Botão opcional de WhatsApp.
- Área Beauty VIP para captura de leads.
- Aviso de transparência sobre links de afiliado.

## IMPORTANTE
Os produtos em products.js são apenas exemplos. Substitua os dados antes de divulgar.

## Onde editar produtos nesta V1
Abra `products.js` e altere:
- name
- platform
- category
- oldPrice
- price
- discount
- image
- description
- note
- affiliateUrl
- whatsapp

## Arquitetura recomendada para a próxima etapa
Para você não precisar editar código diariamente, a versão seguinte deve usar:
- Google Sheets como painel de produtos;
- Google Apps Script como ponte/API;
- GitHub Pages ou Cloudflare Pages para hospedagem;
- Google Sheets/Form/Apps Script para leads e follow-up.

O site continuará público e gratuito; você editará os produtos pelo celular na planilha.

## Hospedagem
GitHub Pages pode publicar o site diretamente de um repositório e não exige uma hospedagem separada. Cloudflare Pages também aceita sites HTML estáticos e possui deploy por Git ou upload.

## Próximo passo
1. Crie uma conta GitHub se ainda não tiver.
2. Crie um repositório público.
3. Envie `index.html`, `style.css`, `app.js` e `products.js`.
4. Ative GitHub Pages em Settings > Pages.
5. Abra o endereço `seuusuario.github.io/nome-do-repositorio`.
6. Depois substitua a lista manual de produtos pela integração com Google Sheets.

## Não coloque neste site
- senhas;
- dados bancários;
- informações pessoais de clientes;
- tokens privados;
- chaves secretas.

O site é público.
